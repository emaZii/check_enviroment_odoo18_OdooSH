/** @odoo-module **/

import { Component, onWillStart, useState } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { rpc } from "@web/core/network/rpc";

// ─────────────────────────────────────────────
//  CSS injected once at module load
// ─────────────────────────────────────────────
const style = document.createElement("style");
style.textContent = `
    .o_environment_banner {
        width: 100%;
        text-align: center;
        padding: 5px 12px;
        font-weight: 700;
        font-size: 12px;
        letter-spacing: 1.5px;
        text-transform: uppercase;
        position: relative;
        z-index: 1000;
        box-sizing: border-box;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: background-color 0.3s ease;
    }

    .o_environment_banner_label {
        display: inline-block;
    }

    /* Pulsing animation for staging — draws attention */
    .o_environment_banner_pulse {
        animation: env-banner-pulse 2.5s ease-in-out infinite;
    }

    @keyframes env-banner-pulse {
        0%,  100% { opacity: 1; }
        50%        { opacity: 0.7; }
    }
`;
document.head.appendChild(style);


// ─────────────────────────────────────────────
//  OWL Component
// ─────────────────────────────────────────────
class EnvironmentBanner extends Component {
    static template = "environment_banner.Banner";
    static props = {};

    setup() {
        this.state = useState({
            loaded: false,
            type: "production",
            label: "",
            color: "",
            bg: "",
            border: "",
            pulse: false,
        });

        onWillStart(async () => {
            try {
                // Calls /web/environment_banner/info which reads ODOO_STAGE_TYPE
                const info = await rpc("/web/environment_banner/info");
                if (info) {
                    Object.assign(this.state, info, { loaded: true });
                }
            } catch (e) {
                // Silently fail — the banner simply won't appear
                console.warn("[EnvironmentBanner] Could not load environment info:", e);
            }
        });
    }
}


// ─────────────────────────────────────────────
//  Register in the systray (top bar of Odoo)
//  sequence: 1  →  appears at the far left
// ─────────────────────────────────────────────
registry.category("systray").add(
    "environment_banner",
    {
        Component: EnvironmentBanner,
        sequence: 1,
    },
    { force: true }
);
