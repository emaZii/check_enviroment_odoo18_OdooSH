{
    'name': 'Environment Banner',
    'version': '18.0.1.0.0',
    'summary': 'Shows a banner indicating the current environment on Odoo.sh (production/staging/dev)',
    'category': 'Technical',
    'author': 'Custom',
    'depends': ['web'],
    'data': [
        'views/templates.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'environment_banner/static/src/js/environment_banner.js',
            'environment_banner/static/src/xml/environment_banner.xml',
        ],
    },
    'installable': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
