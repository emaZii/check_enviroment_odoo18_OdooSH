import os
from odoo import http
from odoo.http import request


class EnvironmentBannerController(http.Controller):

    @http.route('/web/environment_banner/info', type='json', auth='user')
    def get_environment_info(self):
        """
        Reads the ODOO_STAGE_TYPE environment variable set automatically by Odoo.sh:
          - 'production'  → on the production branch
          - 'staging'     → on a staging branch
          - 'dev'         → on a development branch

        Falls back to 'production' if the variable is not set (e.g. local development).
        """
        env_type = os.environ.get('ODOO_STAGE_TYPE', 'production')

        config = {
            'production': {
                'label': '✔ PRODUCTION',
                'color': '#2e7d32',      # dark green
                'bg': '#e8f5e9',          # light green
                'border': '#a5d6a7',
            },
            'staging': {
                'label': '⚠ STAGING',
                'color': '#e65100',      # dark orange
                'bg': '#fff3e0',          # light orange
                'border': '#ffcc80',
                'pulse': True,           # animated border
            },
            'dev': {
                'label': '🛠 DEVELOPMENT',
                'color': '#1565c0',      # dark blue
                'bg': '#e3f2fd',          # light blue
                'border': '#90caf9',
            },
        }

        info = config.get(env_type, config['production'])
        info['type'] = env_type
        return info
